"""
analyze_with_playwright.py

Usage:
  python analyze_with_playwright.py --text "Some text to analyze"

This script will ensure a local HTTP server is running for the project folder (http://localhost:8000),
launch a headless Chromium via Playwright, open the demo page, run the client-side toxicity model,
and print JSON results to stdout.

Requirements:
  pip install playwright requests
  python -m playwright install

"""
import argparse
import json
import os
import subprocess
import sys
import time

try:
    import requests
except Exception:
    print('Please install the requests package: pip install requests', file=sys.stderr)
    sys.exit(1)

try:
    from playwright.sync_api import sync_playwright
except Exception:
    print('Please install Playwright and run `python -m playwright install`', file=sys.stderr)
    print('Install with: pip install playwright', file=sys.stderr)
    sys.exit(1)


PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = 8000
URL = f'http://localhost:{PORT}/'


def server_up(url, timeout=1.0):
    try:
        r = requests.get(url, timeout=timeout)
        return r.status_code == 200
    except Exception:
        return False


def start_server(cwd, port=8000):
    # start a background http.server
    proc = subprocess.Popen([sys.executable, '-m', 'http.server', str(port)], cwd=cwd,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # wait for it to come up
    for _ in range(30):
        if server_up(URL, timeout=1.0):
            return proc
        time.sleep(0.5)
    # if not up, kill and return None
    proc.kill()
    return None


def analyze_text(text, ensure_server=True):
    server_proc = None
    started_server = False
    if ensure_server:
        if not server_up(URL):
            print('Starting local HTTP server...')
            server_proc = start_server(PROJECT_DIR, port=PORT)
            if server_proc is None:
                print('Failed to start local server on port', PORT, file=sys.stderr)
                return 1
            started_server = True
        else:
            print('Local server already running.')

    results = None
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(URL, wait_until='load', timeout=60000)

            # wait for model to be ready (status contains 'Ready' or 'Model loaded')
            page.wait_for_function(
                "() => { const s = document.getElementById('status'); return s && /Ready|loaded/i.test(s.innerText); }",
                timeout=60000,
            )

            # fill text and click analyze
            page.fill('#inputText', text)
            page.click('#analyzeBtn')

            # wait until status becomes 'Done' or error
            page.wait_for_function(
                "() => { const s = document.getElementById('status'); return s && /Done|Error/i.test(s.innerText); }",
                timeout=30000,
            )

            # extract results
            results = page.eval_on_selector_all('#results li',
                                                 "els => els.map(e => { const label = e.querySelector('div') ? e.querySelector('div').innerText : null; const strong = e.querySelector('strong'); const span = e.querySelector('span'); return {label: label, match: strong?strong.innerText:null, score: span?span.innerText:null}; })")

            browser.close()

    finally:
        if started_server and server_proc:
            try:
                server_proc.terminate()
            except Exception:
                pass

    print(json.dumps({'text': text, 'results': results}, indent=2))
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--text', '-t', help='Text to analyze', required=True)
    parser.add_argument('--no-server', action='store_true', help="Don't auto-start local HTTP server; assume it's running")
    args = parser.parse_args()

    ensure_server = not args.no_server
    sys.exit(analyze_text(args.text, ensure_server=ensure_server))


if __name__ == '__main__':
    main()
