let model = null;
const inputEl = document.getElementById('inputText');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultsEl = document.getElementById('results');
const statusEl = document.getElementById('status');
const thresholdEl = document.getElementById('threshold');
const thLabel = document.getElementById('thLabel');

function setStatus(txt){ statusEl.textContent = txt }

async function loadModel(threshold){
  setStatus('Loading model...');
  model = await toxicity.load(threshold);
  setStatus('Model loaded. Ready.');
}

function renderPredictions(predictions){
  resultsEl.innerHTML = '';
  predictions.forEach(pred => {
    const li = document.createElement('li');
    const label = document.createElement('div');
    label.textContent = pred.label.replace('_', ' ');
    const right = document.createElement('div');
    // Single input => results[0]
    const res = pred.results[0];
    const prob = (res.probabilities && res.probabilities.length>1) ? res.probabilities[1] : (res.match?1:0);
    const pct = (prob*100).toFixed(1) + '%';
    const matchText = res.match ? 'Yes' : 'No';
    right.innerHTML = `<strong>${matchText}</strong><span style="margin-left:8px;color:var(--muted)">${pct}</span>`;
    li.appendChild(label);
    li.appendChild(right);
    resultsEl.appendChild(li);
  });
}

async function analyzeText(){
  const text = inputEl.value.trim();
  if(!text){ setStatus('Please enter some text to analyze.'); return; }
  if(!model){ setStatus('Model not ready yet.'); return; }
  setStatus('Analyzing...');
  try{
    const predictions = await model.classify([text]);
    renderPredictions(predictions);
    setStatus('Done');
  }catch(err){
    console.error(err);
    setStatus('Error running model — see console.');
  }
}

analyzeBtn.addEventListener('click', analyzeText);
thresholdEl.addEventListener('input', ()=>{
  thLabel.textContent = thresholdEl.value;
});

// sample buttons
document.querySelectorAll('.sample').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    inputEl.value = btn.textContent;
  });
});

// Reload model when threshold changes (debounced)
let reloadTimer = null;
thresholdEl.addEventListener('change', ()=>{
  const th = parseFloat(thresholdEl.value);
  setStatus('Reloading model with threshold ' + th + ' ...');
  if(reloadTimer) clearTimeout(reloadTimer);
  reloadTimer = setTimeout(()=>{
    loadModel(th);
  }, 300);
});

// initial load
loadModel(parseFloat(thresholdEl.value));
