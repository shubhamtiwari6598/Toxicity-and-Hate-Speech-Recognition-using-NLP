# Toxicity & Hate Speech Detection for Public Portals (SIH-2022-006)

This is a simple client-side demo website for detecting toxic language and hate speech using the TensorFlow.js `toxicity` model. The whole app runs in the browser — no server or Docker required.

Files:

- `index.html` — main page and UI
- `styles.css` — styles
- `script.js` — loads the `toxicity` model and classifies input text

How it works:

- The page loads TensorFlow.js and the `@tensorflow-models/toxicity` model from CDN.
- Enter text in the textarea and press **Analyze**.
- The model returns a set of labels (e.g., `insult`, `toxicity`, `identity_attack`, etc.) with match boolean and a probability.

Run locally:

- Option 1: Open `index.html` directly in your browser (Chrome/Edge/Firefox). The model is loaded from CDN.
- Option 2 (recommended if you see CORS issues): serve the folder with a simple HTTP server. In PowerShell:

```powershell
# using Python (if installed):
python -m http.server 8000
# then open http://localhost:8000 in your browser
```

Notes:

- Model runs entirely in the client; no text is sent to any server.
- The `toxicity` model is intended for research/detection tasks; tune threshold and handle false positives/negatives appropriately in a production system.

If you'd like, I can:

- Add a small backend API to log results (consent required).
- Add batch analysis for datasets and CSV export.
- Add improved UI for labeling spans and saving annotations.
